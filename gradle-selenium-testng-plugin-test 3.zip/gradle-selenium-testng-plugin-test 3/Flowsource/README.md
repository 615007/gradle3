## Selenium TestNG Template with Gradle or Maven as build tools to getting started with

To automate [Selenium Webdriver](https://docs.seleniumhq.org/projects/webdriver/) binaries management in runtime am using [webdrivermanager](https://github.com/bonigarcia/webdrivermanager), an excellent library by [Boni García](https://github.com/bonigarcia) 

### How to use?
Create the Page Objects of your Web application under **_pageobjects_** package and call those Page Objects in your TestNG tests under **_testcases_** package (Sample Page Objects, testcase included in this template)

### How to run?
Issue the below commands in project root directory
 
 ##### Run with TestNG XML
 Various TestNG suite files are available to target single, Parallel execution of Tests & Parallel execution of Dataproviders
 
 Below is for Sequential,Parallel & Data Providers Suite respectively, use IDE to run this TestNG Suite
 ```javascript
 testng.xml
 ```
 ```javascript
 testng_parallel.xml
 ```
 ```javascript
 testng_parallel_dataproviders.xml
 ```
 ##### Gradle
```javascript
./gradlew test -PsequentialSuite
```
```javascript
./gradlew test -PparallelSuite
```
```javascript
./gradlew test -PdataProviderSuite
```
By default it runs in Chrome browser, you can specify which browser to use as well
```javascript
./gradlew test -Dbrowser=firefox
```
You can alternatively change the browser in TestNG XML
```javascript
 <parameter name="browser" value="chrome_headless"/>
```
>If you're on Windows replace `./gradlew` with `gradlew.bat`

Currently supported browsers are 
* chrome
* chrome_headless
* firefox
* edge
* ie
* opera 

##### Maven
```javascript
mvn test
```
Or
```javascript
mvn test -Dbrowser=firefox
```
> Feel free to modify it to your own needs :)