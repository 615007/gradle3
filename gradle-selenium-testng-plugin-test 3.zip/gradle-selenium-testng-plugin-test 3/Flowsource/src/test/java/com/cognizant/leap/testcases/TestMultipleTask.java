package com.cognizant.leap.testcases;

import com.cognizant.leap.pageobjects.HomePage;
import com.cognizant.leap.pageobjects.LoginPage;
import com.cognizant.leap.utils.DriverFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

/**
 * Created by Cognizant Leap Support Team on 19/05/20.
 */
public class TestMultipleTask {

    private WebDriver driver;
    private LoginPage loginPage;
    private HomePage homePage;

    private static final Logger LOGGER = LogManager.getLogger(TestMultipleTask.class);

    @Parameters({"browser"})
    @BeforeClass
    public void setUp(String browser) {
        driver = DriverFactory.getBrowser(browser);
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);

        loginPage.launchUrl();
        loginPage.login();
    }

    @Test(dataProvider = "TestData")
    public void createMultipleTask(String task) {
        LOGGER.info("Creating Task with multiple Data");
        homePage.addTodoTask(task);
        LOGGER.info("LEAP_MESSAGE#FILE#{}#{}", ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE), "CreateMultipleTask.png");
    }

    @Test(dataProvider = "TestData")
    public void updateMultipleTask(String task) {
        LOGGER.info("Updating Multiple Tasks");
        homePage.updateTask(task);
        LOGGER.info("LEAP_MESSAGE#FILE#{}#{}", ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE), "UpdateMultipleTask.png");
    }

    @DataProvider(name = "TestData", parallel = false)
    public Object[][] dataProviderMethod() {
        return new Object[][]{{"Learn Machine Learning"}, {"Learn Python"}, {"Learn R"}};
    }


    @AfterClass
    public void tearDown() {
        homePage.logout();
        driver.quit();
    }
}
