package com.cognizant.leap.pageobjects;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class LoginPage {

    private static final Logger LOGGER = LogManager.getLogger(LoginPage.class);

    private WebDriver driver;

    @FindBy(linkText = "Login")
    public WebElement linkTxtLogin;

    @FindBy(id = "login")
    public WebElement txtUsername;

    @FindBy(id = "password")
    public WebElement txtPassword;

    @FindBy(xpath = "//*[@value='Log In']")
    public WebElement btnLogin;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void launchUrl() {

        LOGGER.info("Launching Application");
        driver.get("http://ec2-18-190-165-247.us-east-2.compute.amazonaws.com:3031/");

//        boolean isApplicationLaunched = checkElement(By.linkText("Login"));
//        Assert.assertTrue(isApplicationLaunched, "Application Launched Successfully");
        LOGGER.info("LEAP_MESSAGE#FILE#{}#{}", ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE), "Application.png");
    }

    public void login() {

        LOGGER.info("Logging into Application");
        txtUsername.sendKeys("leapdemo");
        txtPassword.sendKeys("dd");
       // btnLogin.click();
        //verifyLogin();
    }

    private void verifyLogin() {
        pauseScript(1);
        LOGGER.info("Verifying Login");
        boolean isLoginSuccessful = checkElement(By.linkText("Home"));
        Assert.assertTrue(isLoginSuccessful, "Login Successful");
        LOGGER.info("LEAP_MESSAGE#FILE#{}#{}", ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE), "Login.png");
    }

    public boolean checkElement(By by) {
        boolean chkElement;
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2));
//        WebElement element = wait
//                .until(ExpectedConditions.visibilityOfElementLocated(by));
        return chkElement = true;
    }

    public void pauseScript(int time) {
        try {
            Thread.sleep(1000 * time);
        } catch (Exception e) {

        }
    }
}
