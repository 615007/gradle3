package com.cognizant.leap.utils;

/**
 * Created by Cognizant Leap Support Team on 19/05/20.
 */
public enum BrowserType {

    CHROME,
    CHROME_HEADLESS,
    FIREFOX,
    OPERA,
    EDGE,
    IE

}
