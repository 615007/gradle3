package com.cognizant.leap.pageobjects;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.List;

public class HomePage {

    private static final Logger LOGGER = LogManager.getLogger(HomePage.class);

    private WebDriver driver;

    @FindBy(linkText = "Todos")
    public WebElement btnTodo;

    @FindBy(xpath = "/html/body/app-root/app-list-todos/div[3]/div/button")
    public WebElement btnAdd;

    @FindBy(xpath = "//*[@name='description']")
    public WebElement txtDescription;

    @FindBy(xpath = "//*[@name='targetDate']")
    public WebElement txtTargetDate;

    @FindBy(xpath = "/html/body/app-root/app-todo/div/form/button")
    public WebElement btnSave;

    @FindBy(xpath = "/html/body/app-root/app-list-todos/div[3]/table/tbody/tr[1]/td[5]/button")
    public WebElement btnDeleteFirst;

    @FindBy(xpath = "//*[@class='alert alert-success']")
    public WebElement alert;

    @FindBy(linkText = "Logout")
    public WebElement btnLogout;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void addTodoTask(String task) {
        LOGGER.info("Adding the Task  : " + task);
        pauseScript(1);
        btnTodo.click();
        btnAdd.click();
        txtDescription.sendKeys(task);
        btnSave.click();
        verifyTodoTask(task);
    }

    public void verifyTodoTask(String task) {
        LOGGER.info("Verifying task added  : " + task);
        SoftAssert sf = new SoftAssert();
        pauseScript(1);
        List<WebElement> rowElements = driver.findElements(By.tagName("tr"));

        for (WebElement webElement : rowElements) {
            String addedCourseName = webElement.getText();
            if (addedCourseName.contains(task)) {
                sf.assertTrue(true, "Task " + task + " Added Successfully");
                break;
            }
        }
    }

    public void deleteTask(String task) {
        LOGGER.info("Deleting Task");
        SoftAssert sf = new SoftAssert();
        pauseScript(1);
        List<WebElement> rowElements = driver.findElements(By.tagName("tr"));

        for (int i = 0; i < rowElements.size(); i++) {
            String addedCourseName = rowElements.get(i).getText();
            if (addedCourseName.contains(task)) {
                int index = i + 1;
                String xpath = "/html/body/app-root/app-list-todos/div[3]/table/tbody/tr[" + index + "]/td[5]/button";
                //WebElement btnDelete = driver.findElement(By.xpath(xpath));
                //pauseScript(1);
                //btnDelete.click();
                retryingFindClick(By.xpath(xpath));
                break;
            }
        }

        if (alert.isDisplayed()) {
            sf.assertTrue(true, "Task " + task + " Deleted Successfully");
        } else {
            sf.assertTrue(false, "Task " + task + " Couldn't delete");
        }
    }

    public void updateTask(String task) {
            LOGGER.info("Updating Task");
        SoftAssert sf = new SoftAssert();
        pauseScript(1);
        btnTodo.click();
        pauseScript(1);
        List<WebElement> rowElements = driver.findElements(By.tagName("tr"));
        for (int i = 0; i < rowElements.size(); i++) {
            String addedCourseName = rowElements.get(i).getText();
            if (addedCourseName.contains(task)) {
                int index = i + 1;
                String xpath = "/html/body/app-root/app-list-todos/div[3]/table/tbody/tr[" + index + "]/td[4]/button";
                //WebElement btnUpdate = driver.findElement(By.xpath(xpath));
                //pauseScript(1);
                //btnUpdate.click();
                retryingFindClick(By.xpath(xpath));
                txtDescription.clear();
                txtDescription.sendKeys(task + " and hands on");
                btnSave.click();
                break;
            }
        }
    }

    public void logout() {
        LOGGER.info("Logging out Application");
        cleanUp();
        btnLogout.click();
        boolean isLogout = checkElement(By.linkText("Login again"));
        Assert.assertTrue(isLogout, "Logged Out the Application Successfully");
        LOGGER.info("LEAP_MESSAGE#FILE#{}#{}", ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE), "Logout.png");
    }

    public void cleanUp() {
        pauseScript(1);
        List<WebElement> rowElements = driver.findElements(By.tagName("tr"));
        if (rowElements.size() > 3) {
            for (int i = 0; i < rowElements.size() - 3; i++) {
                int index = i + 1;
                String xpath = "/html/body/app-root/app-list-todos/div[3]/table/tbody/tr[" + index + "]/td[5]/button";
                //WebElement btnDelete = driver.findElement(By.xpath(xpath));
                //pauseScript(1);
                //btnDelete.click();
                retryingFindClick(By.xpath(xpath));
            }
        }

    }

    public boolean checkElement(By by) {

       boolean chkElement;
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
//        WebElement element = wait
//                .until(ExpectedConditions.visibilityOfElementLocated(by));
//
        return  chkElement = true;
    }

    public boolean retryingFindClick(By by) {
        boolean result = false;
        int attempts = 0;
        while (attempts < 2) {
            try {
                pauseScript(1);
                driver.findElement(by).click();
                result = true;
                break;
            } catch (Exception e) {
            }
            attempts++;
        }
        return result;
    }

    public void pauseScript(int time) {
        try {
            Thread.sleep(500 * time);
        } catch (Exception e) {

        }
    }
}
