package com.cognizant.leap.utils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
/**
 * Created by Cognizant Leap Support Team on 19/05/20.
 */
public class Util {

    private Util() {
        // To prevent external instantiation of this class
    }

    /**
     * Function to get the separator string to be used for directories and files
     * based on the current OS
     *
     * @return The file separator string
     */
    public static String getFileSeparator() {
        return System.getProperty("file.separator");
    }

    public  static void takeScreenshot(WebDriver driver){
        ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
    }
}
