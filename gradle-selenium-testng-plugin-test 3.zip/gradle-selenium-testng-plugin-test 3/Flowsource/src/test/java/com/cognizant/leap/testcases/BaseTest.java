package com.cognizant.leap.testcases;

import com.cognizant.leap.pageobjects.HomePage;
import com.cognizant.leap.pageobjects.LoginPage;
import com.cognizant.leap.utils.DriverFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

public class BaseTest {


    protected WebDriver driver;
    protected LoginPage loginPage;
    protected HomePage homePage;

    private static final Logger LOGGER = LogManager.getLogger(TestSingleTask.class);

    @Parameters({"browser"})
    @BeforeMethod
    protected void setUp(String browser) {
        driver = DriverFactory.getBrowser(browser);
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
    }

    @AfterMethod
    protected void tearDown() {
        driver.quit();
    }


}
