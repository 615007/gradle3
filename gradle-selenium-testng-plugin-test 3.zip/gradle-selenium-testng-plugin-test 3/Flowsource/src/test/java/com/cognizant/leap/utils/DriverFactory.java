package com.cognizant.leap.utils;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
//import org.openqa.selenium.opera.OperaDriver;

import java.util.concurrent.TimeUnit;

/**
 * Created by Cognizant Leap Support Team on 19/05/20.
 */
public class DriverFactory {

    public static WebDriver getBrowser(String browser) {

        WebDriver _driver = null;
        String _browserName;
        if (System.getProperty("browser") != null) {
            _browserName = System.getProperty("browser").toUpperCase();
        } else {
            _browserName = browser.toUpperCase();
        }
        //String _browserName = System.getProperty("browser", BrowserType.CHROME_HEADLESS.toString()).toUpperCase();
        //boolean _headless = Boolean.parseBoolean(System.getProperty("headless", String.valueOf(true)));
        BrowserType _browserType = BrowserType.valueOf(_browserName);

        switch (_browserType) {
            case CHROME:
                WebDriverManager.chromedriver().setup();
                _driver = new ChromeDriver();
                break;
            case CHROME_HEADLESS:
                WebDriverManager.chromedriver().setup();
                System.setProperty("webdriver.chrome.driver", "C:\\chromedriver\\chromedriver-win64\\chromedriver.exe");
                
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.addArguments("--headless");
                _driver = new ChromeDriver(chromeOptions);
                break;
            case FIREFOX:
                WebDriverManager.firefoxdriver().setup();
                FirefoxOptions firefoxOptions = new FirefoxOptions();
//                if (_headless) firefoxOptions.addArguments("--headless");
//                _driver = new FirefoxDriver(firefoxOptions);
                break;
            case EDGE:
                WebDriverManager.edgedriver().setup();
                _driver = new EdgeDriver();
                break;
            case IE:
                WebDriverManager.iedriver().setup();
                _driver = new InternetExplorerDriver();
                break;
//            case OPERA:
//                WebDriverManager.operadriver().setup();
//                _driver = new OperaDriver();
//                break;
            default:
//                WebDriverManager.chromedriver().setup();
//                _driver = new ChromeDriver();
                break;
        }
        _driver.manage().window().maximize();
        _driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        return _driver;
    }
}
