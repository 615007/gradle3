package com.cognizant.leap.testcases;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
//import org.springframework.scheduling.config.Task;
import org.testng.annotations.Test;

/**
 * Created by Cognizant Leap Support Team on 19/05/20.
 */
public class TestSingleTask extends BaseTest {

    private static final Logger LOGGER = LogManager.getLogger(TestSingleTask.class);

    @Test(testName = "createTask")
    public void createTask() {

        LOGGER.info("Create Task Test Case");
        loginPage.launchUrl();
        loginPage.login();
        // homePage.addTodoTask("Python");
        // LOGGER.info("LEAP_MESSAGE#FILE#{}#{}", ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE), "CreateTask.png");
        // homePage.logout();
    }

    @Test(testName = "createAndDeleteTask")
    public void createAndDeleteTask() {

        LOGGER.info("Create and Delete Task Test Case");
        loginPage.launchUrl();
        loginPage.login();
        // homePage.addTodoTask("MachineLearning");
        // homePage.deleteTask("MachineLearning");
        // LOGGER.info("LEAP_MESSAGE#FILE#{}#{}", ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE), "CreateAndDeleteTask.png");
        // homePage.logout();
    }

    @Test(testName = "updateTask")
    public void updateTask() {

        LOGGER.info("Update Task Test Case");
        loginPage.launchUrl();
        loginPage.login();
        // homePage.updateTask("Learn Java");
        // LOGGER.info("LEAP_MESSAGE#FILE#{}#{}", ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE), "UpdateTask.png");
        // homePage.logout();
    }

    @Test(testName = "testcase_1")
    public void testcase_1() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
        
    }



    @Test(testName = "testcase_2")
    public void testcase_2() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_3")
    public void testcase_3() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_4")
    public void testcase_4() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_5")
    public void testcase_5() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_6")
    public void testcase_6() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_7")
    public void testcase_7() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_8")
    public void testcase_8() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_9")
    public void testcase_9() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_10")
    public void testcase_10() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_11")
    public void testcase_11() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_12")
    public void testcase_12() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_13")
    public void testcase_13() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_14")
    public void testcase_14() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_15")
    public void testcase_15() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_16")
    public void testcase_16() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_17")
    public void testcase_17() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_18")
    public void testcase_18() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_19")
    public void testcase_19() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_20")
    public void testcase_20() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_21")
    public void testcase_21() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_22")
    public void testcase_22() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_23")
    public void testcase_23() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_24")
    public void testcase_24() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_25")
    public void testcase_25() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_26")
    public void testcase_26() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_27")
    public void testcase_27() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_28")
    public void testcase_28() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_29")
    public void testcase_29() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_30")
    public void testcase_30() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_31")
    public void testcase_31() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_32")
    public void testcase_32() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_33")
    public void testcase_33() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_34")
    public void testcase_34() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_35")
    public void testcase_35() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_36")
    public void testcase_36() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_37")
    public void testcase_37() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_38")
    public void testcase_38() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_39")
    public void testcase_39() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_40")
    public void testcase_40() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_41")
    public void testcase_41() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_42")
    public void testcase_42() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_43")
    public void testcase_43() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_44")
    public void testcase_44() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_45")
    public void testcase_45() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_46")
    public void testcase_46() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_47")
    public void testcase_47() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_48")
    public void testcase_48() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_49")
    public void testcase_49() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_50")
    public void testcase_50() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_51")
    public void testcase_51() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_52")
    public void testcase_52() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_53")
    public void testcase_53() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_54")
    public void testcase_54() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_55")
    public void testcase_55() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_56")
    public void testcase_56() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_57")
    public void testcase_57() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_58")
    public void testcase_58() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_59")
    public void testcase_59() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_60")
    public void testcase_60() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_61")
    public void testcase_61() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_62")
    public void testcase_62() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_63")
    public void testcase_63() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_64")
    public void testcase_64() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_65")
    public void testcase_65() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_66")
    public void testcase_66() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_67")
    public void testcase_67() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_68")
    public void testcase_68() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_69")
    public void testcase_69() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_70")
    public void testcase_70() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_71")
    public void testcase_71() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_72")
    public void testcase_72() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_73")
    public void testcase_73() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_74")
    public void testcase_74() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_75")
    public void testcase_75() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_76")
    public void testcase_76() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_77")
    public void testcase_77() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_78")
    public void testcase_78() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_79")
    public void testcase_79() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_80")
    public void testcase_80() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_81")
    public void testcase_81() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_82")
    public void testcase_82() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_83")
    public void testcase_83() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_84")
    public void testcase_84() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_85")
    public void testcase_85() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_86")
    public void testcase_86() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_87")
    public void testcase_87() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_88")
    public void testcase_88() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_89")
    public void testcase_89() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_90")
    public void testcase_90() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_91")
    public void testcase_91() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_92")
    public void testcase_92() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_93")
    public void testcase_93() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_94")
    public void testcase_94() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_95")
    public void testcase_95() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_96")
    public void testcase_96() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_97")
    public void testcase_97() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_98")
    public void testcase_98() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_99")
    public void testcase_99() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }
    @Test(testName = "testcase_100")
    public void testcase_100() {

        LOGGER.info("Test Case");
        loginPage.launchUrl();
        loginPage.login();
    }

}
